# 旺角街頭英雄傳 — MONG KOK STREET HEROES（霓虹燈下・十一個人的迴響）

A 2D 1-on-1 arcade fighting game in the style of early-90s arcade brawlers, set in Mong Kok between the 1980s and the 2000s.
It has 11 playable "titles" (no real names), plus a final boss, 旺角之魂・霓虹龍. Nobody in it is a villain, and there is no blood.
The visuals are rain, film grain, flickering fluorescent tubes and neon at night.
Between fights, the owner of a late-night 糖水舖, 芳姐, narrates in a 深夜食堂 mood.

The game uses Phaser 3.80.1, bundled with no CDN, so it works offline. It also plays from `file://`, because all 334 images are embedded in `js/assets-embedded.js`.
Its own service-worker cache is `mk-fighter-v2`, and every localStorage key starts with `mk-fighter-`.

## Title screen
The game opens on an attract screen. It shows:
- the big neon logo
- newly drawn large portraits of the 11 heroes above an original landmark montage
- rain, neon flicker and passing light streaks
- a slow minor-key ballad
- the user-supplied epigraph 「念念不忘、必有迴響」
- a blinking 「PRESS ANY BUTTON・按任意鍵開始」

Any key, mouse click, screen tap or gamepad button opens the styled main menu of neon plaques. Esc goes back to the attract screen.

## Modes
- **街機模式 1P vs CPU**: you fight 7 random opponents, each best-of-3.
  - Story scenes come before and after every fight (skippable).
  - Bonus stages come after fights 2, 4 and 6: 食麵 (eat noodles), 執紙皮 (collect cardboard) and 接銅仔 (catch coins).
  - Then you fight the boss on the 唐樓天台 (rooftop) and get your ending.
  - The game offers a continue (10 s) after a loss.
- **純故事模式 (story mode)**: you meet all 10 other heroes, then the boss.
  - Each meeting is pre-fight story → **one single-round fight** → post-fight story. The result doesn't matter; the story always continues.
  - Before each fight you choose: ▶ 觀看對戰 (watch it, CPU vs CPU, the default), 🎮 親自打 (play it yourself) or ⏭ 略過 (skip it).
  - The pause menu also has 略過這場戰鬥 (skip this fight).
- **雙人對戰**: 1P vs 2P on one keyboard, or with two gamepads.
- **自由對戰**: you pick your opponent.
- **觀戰模式**: CPU vs CPU (attract mode).
- **難度 (difficulty)**: 簡單 / 普通 / 困難 (easy / normal / hard). This scales both the CPU and the boss.
- **Unlocking the boss**: once you clear any ending, 霓虹龍 can be picked in 雙人 / 自由 / 觀戰.

## Controls
| | 1P | 2P |
|---|---|---|
| Move / jump / crouch | A D W S (Space = jump) | ← → ↑ ↓ |
| 拳 / 腳 | J / K | Numpad1 / Numpad2 (or `,` `.`) |
| 必殺1 / 必殺2 / 必殺3 | U / I / O | Numpad4 / 5 / 6 (or `;` `'` `]`) |
| 超必殺 (uses 2 bars) | L | Numpad3 (or `/`) |
| 阿飛 outfit (character select) | U or Tab | Numpad4 or `;` |

Other controls:
- Esc / P pauses the game.
- Gamepads are supported.
- On a phone, there is a virtual stick plus 6 buttons. Multi-touch works.

Basic actions:

| Action | How to do it |
|---|---|
| 蹲拳 | ↓ + 拳 |
| 掃腿 | ↓ + 腳 |
| 跳拳 / 跳腳 | 拳 / 腳 in the air |
| Block | hold back |

## Roster
| Title | Style | 必殺1 | 必殺2 | 必殺3 | 超必殺 |
|---|---|---|---|---|---|
| 九龍皇帝 | ink zoner | 御筆・墨跡橫掃 | 墨池・寸步難行 (ink puddle slows) | 拐杖・守護皇土 (counter) | 皇帝聖旨・天書降臨 |
| 龍記大隻佬 | grappler | 燒肉刀・飛身斬 (overhead) | 斬料抱抱・大力摔 (command grab) | 龍記招牌・旋風叉燒臂 (anti-air) | 龍記大霸王・終極抱摔 |
| 先達水貨炒機王 | zoner | 磚頭機・飛擲 | SIM卡・天女散花 | 充電線・長鞭 (anti-air) | 炒機王・全場掃貨 |
| 信和宅男 | trickster | 光碟・迴旋飛盤 | 召喚・鐵皮機械人 (barrier) | 秘技・上上下下左右左右BA (armor buff) | 宅之魂・百連打手掣 |
| 金雞機鋪唱錢大嬸 | counter | 唱錢・銅仔彈 | 腰包・吸錢大法 (absorb) | 代幣筒・當頭棒喝 (guard break) | 金雞大派錢・銅仔雨 |
| 砵蘭街大鑊火師傅 | all-round | 鑊氣・火龍噴 | 鑊鏟・連環快炒 | 鑊蓋・原路奉還 (reflect) | 極速乾炒牛河・猛火大鑊 (grab super) |
| 女人街殺價檔主 | pressure | 貨尾・亂擲 | 計數機・殺到見骨 (dizzy) | 叉衫棍・挑高晾起 | 女人街・全場清貨大減價 |
| 旺角球場波牛 | rushdown | 十二碼・爆射 | 鏟波・飛身鏟 (low) | 倒掛金鈎 (anti-air) | 花墟夜波・世紀入球 |
| 無腳雀仔・阿飛 (suit) | dancer | 恰恰・三步一回頭 | 停擺的時鐘 | 鏡前獨舞 (counter + reflect) | 一生只落地一次 (changes into the vest mid-fight) |
| 無腳雀仔・阿飛 (白背心) | faster, hits harder, takes 6% more damage | 恰恰・赤腳旋步 | 鏡中倒影 | 鏡前獨舞 | 一生只落地一次 |
| 好景商場四仔隱藏仙人 | disc/counter | 碟海・銀光借路 | 格仔・留白之牆 | 布簾・散場回身 | 好景不散・末班放映 |
| 旺角MK妹（25歲成年人） | fast kick rushdown | 街角・踏光連踢 | 鞋帶・低迴掃步 | 天台・躍霓挑踢 | 未完的八拍・霓虹疾奏 |
| **Boss** 旺角之魂・霓虹龍 | neon spirit | 霓虹掌・光字飛彈 | 招牌陣・霓虹落地 | 昇龍・霓虹掌 | 萬家燈火・霓虹龍騰 |

**Boss scaling**

| Difficulty | HP | Damage multiplier | Meter regen per frame | CPU reaction (frames) | Block chance | Super use |
|---|---|---|---|---|---|---|
| 簡單 | 950 | ×0.75 | 0.03 | 20 | 0.25 | 0.4 |
| 普通 | 1120 | ×0.86 | 0.06 | 14 | 0.45 | 0.6 |
| 困難 | 1250 | ×0.95 | 0.10 | 9 | 0.68 | 0.85 |

## Files
- Deploy: `mk-fighter-deploy-v2.zip`. It has `index.html` at the root, plus `_headers`.
- Offline: `mk-fighter-play-offline-v2.zip`. Unzip it, then double-click `mk-fighter/index.html`.
- Tests: `tests/`, using Playwright. The files are moves-test, matchups-test, full-test, story-test, touch-test, soak-test and fps.
- The title lives in one constant: `GAME` in `js/kf-config.js`.

## Story sources (researched, then fictionalised)
See 遊戲說明.txt for the URL list.

## v2 — 十一個人的迴響
Two more original playable heroes: 好景商場四仔隱藏仙人 (58, a fictional composite; non-explicit discs/mosaic/curtain/projector comedy) and 旺角MK妹 (explicitly 25, an original adult street dancer with fast close-range kicks). Both have 18 vector-drawn poses, a portrait, full alternate P2 palette, three specials and a two-bar super. New cover portraits are large original SVG drawings, not upscaled old sprites. Original landmark montage: 先達廣場, 信和中心, 砵蘭街, 旺角電腦中心, 波鞋街. Vector sources: art-source-v2/; generator: tools/art_v2.py (CairoSVG/Pillow).

All eleven arcs and the neon spirit's epilogue were rewritten as fictional-composite lives: unresolved loss, a concrete gesture of care, and a reason to keep going. The user-supplied epigraph 「念念不忘、必有迴響」 means that care may continue in another person even when a place or loved one does not return. It is not claimed as our original phrase. All story dialogue is original fiction except the two user-provided phrases, and no invented biographical events are attributed to a real person. Detailed dated research and provenance distinctions are in 遊戲說明.txt.

v1 localStorage preference/unlock keys remain compatible. The service worker uses mk-fighter-v2, removes only older mk-fighter-* caches, and revalidates network responses; scripts and art carry v2 cache-busting queries.

Archives: mk-fighter-deploy-v2.zip (web host, index.html at root), mk-fighter-play-offline-v2.zip (double-click mk-fighter/index.html, embedded art only). Old archives and source rollback are preserved under /workspace/mk-rollback-20261118-183725. No deployment performed.
